class Model {
  String barcode, name, netweight, price, point, key;
  Model(
      {this.barcode,
      this.name,
      this.netweight,
      this.price,
      this.point,
      this.key});
}
