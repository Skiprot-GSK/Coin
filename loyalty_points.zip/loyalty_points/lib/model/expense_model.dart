class Expense {
  final String name;
  final double cost;

  Expense({this.name, this.cost});
}
